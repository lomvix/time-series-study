API
====

.. currentmodule:: pytorch_forecasting

.. autosummary::
   :toctree: api
   :template: custom-module-template.rst
   :recursive:

   data
   models
   metrics
   utils
