Tutorials
==========

.. _tutorials:

The following tutorials can be also found as `notebooks on GitHub <https://github.com/jdb78/pytorch-forecasting/tree/master/docs/source/tutorials>`_.

.. toctree::
   :titlesonly:
   :maxdepth: 2

   tutorials/stallion
   tutorials/ar
   tutorials/building
   tutorials/deepar
   tutorials/nhits
