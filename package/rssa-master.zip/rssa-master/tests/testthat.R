library(testthat)
library(Rssa)

test_check("Rssa")
